package com.example.uasandroid_abdulrohmanti411;

import android.content.Context;

class Volley {
    public static RequestQueue newRequestQueue(Context context) {
    }
}
