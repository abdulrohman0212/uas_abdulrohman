package com.example.uasandroid_abdulrohmanti411;

class RequestQueue {
    public void add(JsonObjectRequest jsonObjectRequest) {
    }
}
